Barbie Fun — Netlify static frontend

Upload the contents of this ZIP to Netlify Drop, or use this folder as the publish directory.

Important:
This is the frontend build only. The launchpad currently calls the separate Express API server
for database-backed launches, admin functions, live stream settings, token launch transactions,
and storage. Those API routes will not work on a static Netlify upload unless you deploy the API
separately and update the frontend API base URL/proxy configuration.
