import { useState } from "react";
import {
  ArrowUpRight,
  Check,
  Clipboard,
  ExternalLink,
  Send,
  ShieldCheck,
  Twitter,
} from "lucide-react";

const VOTE_ACCOUNT =
  "BhoHtTEp56AvhGM4qAe6rujVjYwVB8NGXE3z8CJFTBLE";

const OFFICIAL_STAKING_URL = "https://app.xdex.xyz/valistake";

const X_URL = "https://x.com/BARBIEFUNV2";
const TELEGRAM_URL = "https://t.me/barbiefunv2";

const steps = [
  {
    number: "01",
    title: "Copy Vote Account",
    description: "Copy the validator vote account shown above.",
  },
  {
    number: "02",
    title: "Open Staking Portal",
    description: "Open the official staking portal in a new tab.",
  },
  {
    number: "03",
    title: "Paste Address",
    description: "Paste the copied vote account into the staking interface.",
  },
  {
    number: "04",
    title: "Select BarbieFun (X1)",
    description: "Find and select BarbieFun Validator (X1) as your validator.",
  },
  {
    number: "05",
    title: "Stake",
    description:
      "Complete the staking process directly through the official portal.",
  },
];

function App() {
  const [copied, setCopied] = useState(false);

  async function copyVoteAccount() {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(VOTE_ACCOUNT);
      } else {
        const textArea = document.createElement("textarea");
        textArea.value = VOTE_ACCOUNT;
        textArea.style.position = "fixed";
        textArea.style.opacity = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand("copy");
        textArea.remove();
      }

      setCopied(true);

      window.setTimeout(() => {
        setCopied(false);
      }, 2200);
    } catch {
      window.alert("Unable to copy the vote account. Please copy it manually.");
    }
  }

  function openOfficialPortal() {
    window.open(
      OFFICIAL_STAKING_URL,
      "_blank",
      "noopener,noreferrer"
    );
  }

  return (
    <main className="site-shell" id="top">
      <div className="background-orb background-orb-one" />
      <div className="background-orb background-orb-two" />

      <nav className="navbar" aria-label="Primary navigation">
        <a className="brand" href="#top" aria-label="BarbieFun Validator home">
          <img className="brand-logo" src="/logo.png" alt="BarbieFun Validator logo" />

          <span className="brand-name">
            BARBIEFUN <strong>VALIDATOR (X1)</strong>
          </span>
        </a>

        <div className="nav-right">
          <div className="social-links">
            <a
              className="social-icon-link"
              href={X_URL}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Follow BarbieFun on X"
              title="Follow on X"
            >
              <Twitter size={17} aria-hidden="true" />
            </a>

            <a
              className="social-icon-link"
              href={TELEGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Join BarbieFun on Telegram"
              title="Join on Telegram"
            >
              <Send size={17} aria-hidden="true" />
            </a>
          </div>
        </div>
      </nav>

      <section className="hero" aria-labelledby="hero-title">
        <img className="hero-logo" src="/logo.png" alt="BarbieFun Validator (X1) logo" />

        <div className="eyebrow">
          <span className="eyebrow-dot" />
          OFFICIAL VALIDATOR GUIDE
        </div>

        <h1 id="hero-title">
          Stake with
          <br />
          <em>BarbieFun (X1).</em>
        </h1>

        <p className="hero-description">
          Join the BarbieFun Validator (X1) community through the official
          staking portal. Simple, transparent, and always in your control.
        </p>

        <div className="hero-actions">
          <button
            className="button button-primary"
            type="button"
            onClick={copyVoteAccount}
          >
            {copied ? (
              <Check size={18} aria-hidden="true" />
            ) : (
              <Clipboard size={18} aria-hidden="true" />
            )}

            {copied ? "Copied!" : "Copy vote account"}
          </button>

          <button
            className="button button-secondary"
            type="button"
            onClick={openOfficialPortal}
          >
            Open official staking
            <ArrowUpRight size={18} aria-hidden="true" />
          </button>
        </div>

        <p className="no-custody">
          <ShieldCheck size={16} aria-hidden="true" />
          No wallet connection. No credentials collected.
        </p>
      </section>

      <section className="account-card" aria-labelledby="account-title">
        <div className="card-label" id="account-title">
          VALIDATOR VOTE ACCOUNT
        </div>

        <div className="account-row">
          <code title={VOTE_ACCOUNT}>{VOTE_ACCOUNT}</code>

          <button
            className="copy-icon-button"
            type="button"
            onClick={copyVoteAccount}
            aria-label="Copy validator vote account"
            title="Copy validator vote account"
          >
            {copied ? (
              <Check size={19} aria-hidden="true" />
            ) : (
              <Clipboard size={19} aria-hidden="true" />
            )}
          </button>
        </div>

        {copied && (
          <div className="copied-message" role="status" aria-live="polite">
            <Check size={14} aria-hidden="true" />
            Vote account copied to clipboard
          </div>
        )}

        <div className="account-footer">
          <span>Use this address on the official portal</span>

          <span className="instructional-label">
            <ShieldCheck size={14} aria-hidden="true" />
            Instructional only
          </span>
        </div>
      </section>

      <section className="guide-section" id="guide" aria-labelledby="guide-title">
        <div className="section-heading">
          <div>
            <div className="eyebrow eyebrow-left">
              <span className="eyebrow-dot" />
              THE PROCESS
            </div>

            <h2 id="guide-title">How to join BarbieFun (X1)</h2>
          </div>

          <p>
            Follow these five steps to stake directly through the official
            staking interface.
          </p>
        </div>

        <div className="steps-grid">
          {steps.map((step) => (
            <article className="step-card" key={step.number}>
              <span className="step-number">{step.number}</span>

              <h3>{step.title}</h3>

              <p>{step.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="security-notice" aria-labelledby="security-title">
        <div className="security-icon">
          <ShieldCheck size={24} aria-hidden="true" />
        </div>

        <div>
          <h2 id="security-title">Security notice</h2>

          <p>Only use the official staking portal:</p>

          <a
            className="official-link"
            href={OFFICIAL_STAKING_URL}
            target="_blank"
            rel="noopener noreferrer"
          >
            app.xdex.xyz/valistake
            <ExternalLink size={14} aria-hidden="true" />
          </a>

          <p className="never-request">
            This page will never request or collect seed phrases, private keys,
            recovery phrases, or wallet passwords.
          </p>
        </div>
      </section>

      <footer className="footer">
        <span>© {new Date().getFullYear()} BarbieFun Validator (X1)</span>

        <div className="footer-social">
          <a
            href={X_URL}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Follow BarbieFun on X"
          >
            <Twitter size={14} aria-hidden="true" />
            X
          </a>

          <a
            href={TELEGRAM_URL}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Join BarbieFun on Telegram"
          >
            <Send size={14} aria-hidden="true" />
            Telegram
          </a>
        </div>

        <span>Built for clarity · Powered by choice</span>
      </footer>
    </main>
  );
}

export default App;
